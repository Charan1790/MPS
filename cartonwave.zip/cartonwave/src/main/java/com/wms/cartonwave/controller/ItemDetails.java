package com.wms.cartonwave.controller;

public class ItemDetails {
	private String article;
	private String item_id;
    private int qty;
    private String distro_nbr;
    private String dest_id;
    private String pick_type;
    private String carrier_code;
    private String task_id;
    private String work_directive_id;
    private String pick_from_container_id;
    private String tran_datetime;
    
	public String getArticle() {
		return article;
	}
	public void setArticle(String article) {
		this.article = article;
	}
	public String getItem_id() {
		return item_id;
	}
	public void setItem_id(String item_id) {
		this.item_id = item_id;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getDistro_nbr() {
		return distro_nbr;
	}
	public void setDistro_nbr(String distro_nbr) {
		this.distro_nbr = distro_nbr;
	}
	public String getDest_id() {
		return dest_id;
	}
	public void setDest_id(String dest_id) {
		this.dest_id = dest_id;
	}
	public String getPick_type() {
		return pick_type;
	}
	public void setPick_type(String pick_type) {
		this.pick_type = pick_type;
	}
	public String getCarrier_code() {
		return carrier_code;
	}
	public void setCarrier_code(String carrier_code) {
		this.carrier_code = carrier_code;
	}
	public String getTask_id() {
		return task_id;
	}
	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}
	public String getWork_directive_id() {
		return work_directive_id;
	}
	public void setWork_directive_id(String work_directive_id) {
		this.work_directive_id = work_directive_id;
	}
	public String getPick_from_container_id() {
		return pick_from_container_id;
	}
	public void setPick_from_container_id(String pick_from_container_id) {
		this.pick_from_container_id = pick_from_container_id;
	}
	public String getTran_datetime() {
		return tran_datetime;
	}
	public void setTran_datetime(String tran_datetime) {
		this.tran_datetime = tran_datetime;
	}
	
}
