package com.wms.cartonwave.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class WebLogicJNDILookup {
	
	public static void main(String[] args) {
		
		  Context ctx = null;
		  Connection conn = null;
		  ResultSet rs = null;		 	

		  try {
		    ctx = new InitialContext();
		    
		    DataSource ds = (DataSource)  ctx.lookup("jdbc/wms_db");
		    
		    conn = ds.getConnection();
		    
		    PreparedStatement stmt =   conn.prepareStatement("select country_name from countries");
		    
		    rs =stmt.executeQuery();
		    
		    while(rs.next())
		    
		    	System.out.println(rs.getString("country_name"));
		  }
		  
                  catch (NamingException e) {
		    e.printStackTrace();
		  }
 
                  catch (SQLException e) {
			e.printStackTrace();
		  }

		  finally {

		    try {
		    	conn.close();
		    	rs.close();
		    	ctx.close();
		    }
		    catch (Exception e) {
		    	e.printStackTrace();
		    }

		  }
	}
}
