package com.wms.cartonwave.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wms.cartonwave.dao.CartonWaveDAO;

import org.apache.log4j.Logger; 

@RestController
public class CartonWaveController {
	
	@Autowired
	private CartonWaveDAO cartonWaveDao;
	
	private final static Logger LOGGER = Logger.getLogger(CartonWaveController.class.getName()); 
	
	@PostMapping(value = "/carton", headers="Accept=application/json", consumes="application/json",produces="application/json")
	public ResponseEntity<CartonWaveResponse> getCartonDataResponse(@RequestBody CartonDataRequest sub) throws JsonProcessingException, SQLException {
		
		CartonWaveResponse cartonWaveResponse = null;
		try 
		{	
			
			ObjectMapper mapper = new ObjectMapper();
			String json = "";
			
			json = mapper.writeValueAsString(sub);
			LOGGER.info("CartonWaveController - getCartonDataResponse: Request ->" + json);	
			
			cartonWaveResponse = new CartonWaveResponse();
			cartonWaveResponse = cartonWaveDao.getCartonData(sub.getCarton_no(), json);						
			json = mapper.writeValueAsString(cartonWaveResponse);
			
			LOGGER.info("CartonWaveController - getCartonDataResponse: Response ->" + json);
			
		}catch(Exception e) {
			LOGGER.error("Exception in CartonWaveController:");			
			 e.printStackTrace();
			
		}
		return new ResponseEntity<CartonWaveResponse>(cartonWaveResponse, HttpStatus.OK);
	}
	
	
}
	
