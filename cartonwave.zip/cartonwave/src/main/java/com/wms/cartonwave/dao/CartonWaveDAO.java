package com.wms.cartonwave.dao;

import java.sql.SQLException;

import com.wms.cartonwave.controller.*;

public interface CartonWaveDAO {
	
		CartonWaveResponse getCartonData(String carton_no, String json) throws SQLException;
	
}
