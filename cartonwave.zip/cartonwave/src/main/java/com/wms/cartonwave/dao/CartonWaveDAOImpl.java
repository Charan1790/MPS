package com.wms.cartonwave.dao;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.sql.DataSource;

import org.apache.log4j.Logger; 

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wms.cartonwave.controller.*;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import javax.naming.InitialContext;

@Transactional
@Repository("CartonWaveDAO")
public class CartonWaveDAOImpl implements CartonWaveDAO{
	
	private final static Logger LOGGER = Logger.getLogger(CartonWaveController.class.getName()); 
	
	CartonWaveDAOImpl() {
		System.out.println(" Default Constructor bookingCreationDAO is Executed");
	}
	
	@Override
	public CartonWaveResponse getCartonData(String carton_no, String json) throws SQLException {
		// TODO Auto-generated method stub
		LOGGER.info("Start Executing CartonWaveDAOImpl - getCartonData");
		
		Context ctx = null;
		Connection conn = null;			
		OracleCallableStatement oracleCallableStmt = null;
		CartonWaveResponse cartonWaveResponse = null;
		String packageCallStmt = "{call XX_PTL.MAKE_CARTON(?,?)}"; 
		try{
			ctx = new InitialContext();
		    DataSource ds = (DataSource)ctx.lookup("jdbc/wms");
		    conn = ds.getConnection();
			cartonWaveResponse = new CartonWaveResponse();
			
			if(conn!=null) {
				oracleCallableStmt = (OracleCallableStatement) conn.prepareCall(packageCallStmt);
				Clob clob = conn.createClob();
				clob.setString(1, json);
				oracleCallableStmt.setClob(1, clob);	
				oracleCallableStmt.registerOutParameter(2, OracleTypes.VARCHAR);
				oracleCallableStmt.executeUpdate();		
				cartonWaveResponse.setCarton_no(carton_no);
				cartonWaveResponse.setMessage(((OracleCallableStatement) oracleCallableStmt).getString(2));			
			}else {
				cartonWaveResponse.setCarton_no(null);
				cartonWaveResponse.setMessage("Error connecting to DB");
			}
			LOGGER.info("End of CartonWaveDAOImpl - getCartonData");
			
		}catch(Exception e){
			e.printStackTrace();			
		}finally{
			try {
				if(conn!=null)
					conn.close();
				if(oracleCallableStmt!=null)
					oracleCallableStmt.close();
				if(ctx!=null)
					ctx.close();
		    }
		    catch (Exception e) {
		    	e.printStackTrace();
		    }
		}
		return cartonWaveResponse;
	}
	
	/*
	 * private Connection getConnection(Connection conn) {
	 * 
	 * try {
	 * 
	 * LOGGER.info("Start executing CartonWaveDAOImpl - getConnection"); InputStream
	 * inputStream =
	 * Thread.currentThread().getContextClassLoader().getResourceAsStream
	 * ("config.properties"); Properties prop = new Properties();
	 * prop.load(inputStream);
	 * 
	 * final String JDBC_DRIVER = prop.getProperty("cartonDbDriver"); final String
	 * DB_URL = prop.getProperty("cartonDbURL"); final String USER =
	 * prop.getProperty("cartonDbUser"); final String PASS =
	 * prop.getProperty("cartonDbPassword");
	 * 
	 * Class.forName(JDBC_DRIVER); LOGGER.info("Connecting to database..."); conn =
	 * DriverManager.getConnection(DB_URL,USER,PASS);
	 * 
	 * }catch(Exception e) { e.printStackTrace(); }
	 * LOGGER.info("End of CartonWaveDAOImpl - getConnection"); return conn; }
	 */
	
}
