package com.wms.cartonwave.controller;

import java.util.ArrayList;

public class CartonDataRequest {
	 private String facility_id;
	 private String carton_no;
	 private String customer_ord;
	 private String wave;
	 private String carton_open_datetime;
	 private String carton_close_datetime;
	 
	 private ArrayList<ItemDetails> itemdetails;
	 
		public String getFacility_id() {
			return facility_id;
		}
		public void setFacility_id(String facility_id) {
			this.facility_id = facility_id;
		}
		public String getCarton_no() {
			return carton_no;
		}
		public void setCarton_no(String carton_no) {
			this.carton_no = carton_no;
		}
		public String getCustomer_ord() {
			return customer_ord;
		}
		public void setCustomer_ord(String customer_ord) {
			this.customer_ord = customer_ord;
		}
		public String getWave() {
			return wave;
		}
		public void setWave(String wave) {
			this.wave = wave;
		}
		public String getCarton_open_datetime() {
			return carton_open_datetime;
		}
		public void setCarton_open_datetime(String carton_open_datetime) {
			this.carton_open_datetime = carton_open_datetime;
		}
		public String getCarton_close_datetime() {
			return carton_close_datetime;
		}
		public void setCarton_close_datetime(String carton_close_datetime) {
			this.carton_close_datetime = carton_close_datetime;
		}
		public ArrayList<ItemDetails> getItemdetails() {
			return itemdetails;
		}
		public void setItemdetails(ArrayList<ItemDetails> itemdetails) {
			this.itemdetails = itemdetails;
		}
	
}
