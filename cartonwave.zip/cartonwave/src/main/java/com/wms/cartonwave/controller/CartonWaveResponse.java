package com.wms.cartonwave.controller;

public class CartonWaveResponse {
	
	private String carton_no;
	private String message;
	
	public String getCarton_no() {
		return carton_no;
	}
	public void setCarton_no(String carton_no) {
		this.carton_no = carton_no;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
