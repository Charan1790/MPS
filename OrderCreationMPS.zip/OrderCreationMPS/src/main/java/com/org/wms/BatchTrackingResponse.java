package com.org.wms;

import java.util.List;

public class BatchTrackingResponse {
	private Meta meta;
	private List<BatchTrackingResult> result;
	
	public Meta getMeta() {
		return meta;
	}
	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	public List<BatchTrackingResult> getResult() {
		return result;
	}
	public void setResult(List<BatchTrackingResult> result) {
		this.result = result;
	}
		
}
