package com.org.wms;

public class PickupInfo {
	
	private int lat;
	private String city;
	private int lon;
	private String name;
	private String time;
	private String email;
	private String phone;
	private String state;
	private String address;
	private String district;
	private String landmark;
    private String phone_code;
    private String postal_code;
    private String country_code;
    
	/*
	 * public PickupInfo(int lat, String city, int lon, String name, String time,
	 * String email, String phone, String state, String address, String district,
	 * String landmark, String phone_code, String postal_code, String country_code)
	 * { super(); this.lat = lat; this.city = city; this.lon = lon; this.name =
	 * name; this.time = time; this.email = email; this.phone = phone; this.state =
	 * state; this.address = address; this.district = district; this.landmark =
	 * landmark; this.phone_code = phone_code; this.postal_code = postal_code;
	 * this.country_code = country_code; }
	 */
	
	public int getLat() {
		return lat;
	}
	public void setLat(int lat) {
		this.lat = lat;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getLon() {
		return lon;
	}
	public void setLon(int lon) {
		this.lon = lon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getPhone_code() {
		return phone_code;
	}
	public void setPhone_code(String phone_code) {
		this.phone_code = phone_code;
	}
	public String getPostal_code() {
		return postal_code;
	}
	public void setPostal_code(String postal_code) {
		this.postal_code = postal_code;
	}
	public String getCountry_code() {
		return country_code;
	}
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
    
}
