package com.org.wms;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.sun.jersey.api.client.Client;
//import com.sun.jersey.api.client.WebResource;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;  

@RestController
public class OrderCreationMPSController {
	
	private final static Logger LOGGER = Logger.getLogger(OrderCreationMPSController.class.getName()); 
	ObjectMapper mapper = new ObjectMapper();
	String json = "";
	
	@PostMapping(value = "/ordercreation", headers="Accept=application/json", consumes="application/json", produces = "application/json")
	public ResponseEntity<OrderCreationMPSResponse> getOrderCreationResponse(@RequestBody OrderCreationMPSRequest sub) throws JsonProcessingException {
		
			OrderCreationMPSResponse ordCreationResponse = null;
		
			try {		
				json = mapper.writeValueAsString(sub);
				LOGGER.info("Started executing OrderCreationMPS - getOrderCreationResponse: Request -> "+json);
			
				String uri ="ordercreation";				
				int itemSize = sub.getShipment_details().getItems().size();				
				RestTemplate restTemplate = new RestTemplate();
				
				PickupInfo pickUpInfo = new PickupInfo();
				pickUpInfo.setLat(sub.getPickup_info().getLat());
				pickUpInfo.setCity(sub.getPickup_info().getCity());
				pickUpInfo.setLon(sub.getPickup_info().getLon());
				pickUpInfo.setName(sub.getPickup_info().getName());
				pickUpInfo.setTime(sub.getPickup_info().getTime());
				pickUpInfo.setEmail(sub.getPickup_info().getEmail());
				pickUpInfo.setPhone(sub.getPickup_info().getPhone());
				pickUpInfo.setState(sub.getPickup_info().getState());
				pickUpInfo.setAddress(sub.getPickup_info().getAddress());
				pickUpInfo.setDistrict(sub.getPickup_info().getDistrict());
				pickUpInfo.setLandmark(sub.getPickup_info().getLandmark());
				pickUpInfo.setPhone_code(sub.getPickup_info().getPhone_code());
				pickUpInfo.setPostal_code(sub.getPickup_info().getPostal_code());
				pickUpInfo.setCountry_code(sub.getPickup_info().getCountry_code());
				
				DropInfo dropInfo = new DropInfo();
				dropInfo.setLat(sub.getDrop_info().getLat());
				dropInfo.setCity(sub.getDrop_info().getCity());
				dropInfo.setLon(sub.getDrop_info().getLon());
				dropInfo.setName(sub.getDrop_info().getName());		
				dropInfo.setEmail(sub.getDrop_info().getEmail());
				dropInfo.setPhone(sub.getDrop_info().getPhone());
				dropInfo.setState(sub.getDrop_info().getState());
				dropInfo.setAddress(sub.getDrop_info().getAddress());
				dropInfo.setDistrict(sub.getDrop_info().getDistrict());
				dropInfo.setLandmark(sub.getDrop_info().getLandmark());
				dropInfo.setPhone_code(sub.getDrop_info().getPhone_code());
				dropInfo.setPostal_code(sub.getDrop_info().getPostal_code());
				dropInfo.setCountry_code(sub.getDrop_info().getCountry_code());
				
				List<Items> items = new ArrayList<Items>();
				System.out.println("Items list Size"+itemSize);
				for (int i=0; i<itemSize; i++) {
					items.add(i, sub.getShipment_details().getItems().get(i));			
				}
				
				ShipmentDetails shipmentDetails = new ShipmentDetails();
				
				shipmentDetails.setItems(items);
				shipmentDetails.setWeight(sub.getShipment_details().getWeight());
				shipmentDetails.setOrder_id(sub.getShipment_details().getOrder_id());
				shipmentDetails.setCod_value(sub.getShipment_details().getCod_value());
				shipmentDetails.setOrder_type(sub.getShipment_details().getOrder_type());
				shipmentDetails.setInvoice_date(sub.getShipment_details().getInvoice_date());
				shipmentDetails.setCurrency_code(sub.getShipment_details().getCurrency_code());
				shipmentDetails.setDelivery_type(sub.getShipment_details().getDelivery_type());
				shipmentDetails.setInvoice_value(sub.getShipment_details().getInvoice_value());
				shipmentDetails.setInvoice_number(sub.getShipment_details().getInvoice_number());
				shipmentDetails.setCourier_partner(sub.getShipment_details().getCourier_partner());
				shipmentDetails.setReference_number(sub.getShipment_details().getReference_number());
				shipmentDetails.setHeight(sub.getShipment_details().getHeight());
				shipmentDetails.setLength(sub.getShipment_details().getLength());
				shipmentDetails.setBreadth(sub.getShipment_details().getBreadth());
				
				Additional additional = new Additional();
				additional.setAccount_code(sub.getAdditional().getAccount_code());
				additional.setLabel(sub.getAdditional().isLabel());
				additional.setDuty_fee_paid_by(sub.getAdditional().getDuty_fee_paid_by());
				
				OrderCreationMPSRequest ordCreationRequest = new OrderCreationMPSRequest();  
				OrderCreationRequest orderCreationReq = new OrderCreationRequest();
				ordCreationRequest.setPickup_info(pickUpInfo);
				ordCreationRequest.setDrop_info(dropInfo);
				ordCreationRequest.setShipment_details(shipmentDetails);
				ordCreationRequest.setAdditional(additional);
				ordCreationRequest.setPrinter_name(sub.getPrinter_name());
				
				orderCreationReq.setPickup_info(pickUpInfo);
				orderCreationReq.setDrop_info(dropInfo);
				orderCreationReq.setShipment_details(shipmentDetails);
				orderCreationReq.setAdditional(additional);
				
				uri = readURL(uri);
				
				ordCreationResponse = restTemplate.postForObject(uri, orderCreationReq, OrderCreationMPSResponse.class);
				json = mapper.writeValueAsString(ordCreationResponse);
				
				String labelURL = ordCreationResponse.getResult().getLabel();
				String courierPath = "";
				courierPath = "LabelPDFFileLocation_"+shipmentDetails.getCourier_partner();
				String filePath = readURL(courierPath);
				String fileName = "";
				
				LOGGER.info( "FilePath for Courier "+shipmentDetails.getCourier_partner()+ " is " + filePath);
				
				fileName = PdfLabelDownload.DownloadPDFFromURL(labelURL, filePath, shipmentDetails.getOrder_id());
				
				if((sub.getPrinter_name()!=null) && (!sub.getPrinter_name().isEmpty())) {
					PdfLabelDownload.PrintPDFFromURL(sub.getPrinter_name(), filePath, fileName);
				}
				
				LOGGER.info("End of OrderCreationMPS - getOrderCreationResponse: Response -> "+json);	
			}catch(Exception e) {
				LOGGER.error("Error executing OrderCreationMPS - getOrderCreationResponse");
				e.printStackTrace();
		}
		return new  ResponseEntity<OrderCreationMPSResponse>( ordCreationResponse, HttpStatus.OK );		
	}
	
	@GetMapping(value = "/batchtracking/{startDate}/{endDate}", headers="Accept=application/json", produces="application/json")
	public ResponseEntity<BatchTrackingResponse> getBatchTrackingResponse( @PathVariable("startDate") String startDate, @PathVariable("endDate") String endDate) throws JsonProcessingException {
			
		BatchTrackingResponse batchResponse = null;
		try {
			LOGGER.info("Started executing OrderCreationMPS - getBatchTrackingResponse: Start and End dates ="+startDate+": and :"+endDate);
			RestTemplate restTemplate = new RestTemplate();
			String uri = "batchtracking";
			uri = readURL(uri);
			String date = "&start_date="+ startDate +"&end_date="+ endDate;
			String url = uri + date;
			System.out.print("***Formed URL***" + url);
			
			batchResponse = restTemplate.getForObject(url, BatchTrackingResponse.class);
			
			json = mapper.writeValueAsString(batchResponse);
			
			LOGGER.info("End of OrderCreationMPS - getBatchTrackingResponse: Response -> " +json);
		}catch(Exception e) {
			LOGGER.error("Error processing OrderCreationMPS - getBatchTrackingResponse");
			e.printStackTrace();
		}
			return new ResponseEntity<BatchTrackingResponse>( batchResponse, HttpStatus.OK );
		
	}
	
	@GetMapping(value = "/batchpolling/{waybill}/{cp_id}", headers="Accept=application/json")
	public Object getBatchPollingResponse( @PathVariable("waybill") String waybill, @PathVariable("cp_id") String cp_id) throws JsonProcessingException {

		Object response = null;
		try {
			LOGGER.info("Started executing OrderCreationMPS - getBatchPollingResponse: waybill and cp_id ="+waybill+": and :"+cp_id);
			RestTemplate restTemplate = new RestTemplate();
			String uri = "batchpolling";
			uri = readURL(uri);
			String billCpId = "&waybill="+ waybill +"&cp_id="+ cp_id;
			String url = uri + billCpId;
			System.out.print("***Formed URL***" + url);
			
			response = restTemplate.getForObject(url, Object.class);
			
			json = mapper.writeValueAsString(response);
			
			LOGGER.info("End of OrderCreationMPS - getBatchPollingResponse: Response -> " +json);
			
		}catch(Exception e) {
			LOGGER.error("Error processing OrderCreationMPS - getBatchPollingResponse");
			e.printStackTrace();
		}
		return response;
		
	}
	
	public String readURL(String uri) {
		try {
			
			LOGGER.info("Started executing OrderCreationMPS - readURL: "+uri);
			InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream ("config.properties");
		    Properties prop = new Properties();
		    prop.load(inputStream);
		    
		    if(uri.equalsIgnoreCase("ordercreation")) {
		    	uri = prop.getProperty("OrderCreationURL");
		    }else if (uri.equalsIgnoreCase("batchtracking")){
		    	uri = prop.getProperty("BatchTrackingURL");
		    }else if (uri.equalsIgnoreCase("batchpolling")){
		    	uri = prop.getProperty("BatchTrackingPollingURL");
		    }else {
		    	uri = prop.getProperty(uri);
		    }
		    LOGGER.info("End of OrderCreationMPS - readURL "+ uri);
		    
		}catch(Exception e) {
			LOGGER.error("Error while fetching property values from Config.properties");
			e.printStackTrace();
		}
		return uri;
	}
}
	
