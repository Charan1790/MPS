package com.org.wms;

public class OrderCreationMPSRequest {
	
	private PickupInfo pickup_info;
	private DropInfo drop_info;
	private ShipmentDetails shipment_details;
	private Additional additional;
	private String printer_name;
	
	public PickupInfo getPickup_info() {
		return pickup_info;
	}
	
	public void setPickup_info(PickupInfo pickup_info) {
		this.pickup_info = pickup_info;
	}
	
	public DropInfo getDrop_info() {
		return drop_info;
	}
	
	public void setDrop_info(DropInfo drop_info) {
		this.drop_info = drop_info;
	}
	
	public ShipmentDetails getShipment_details() {
		return shipment_details;
	}
	
	public void setShipment_details(ShipmentDetails shipment_details) {
		this.shipment_details = shipment_details;
	}
	public Additional getAdditional() {
		return additional;
	}
	public void setAdditional(Additional additional) {
		this.additional = additional;
	}
		
	public String getPrinter_name() {
		return printer_name;
	}

	public void setPrinter_name(String printer_name) {
		this.printer_name = printer_name;
	}
		
}
