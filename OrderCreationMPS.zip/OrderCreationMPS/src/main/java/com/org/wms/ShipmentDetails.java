package com.org.wms;

import java.util.List;

public class ShipmentDetails {

	private List<Items> items;
	
	private int weight;
    private String order_id;
    private int cod_value;
    private String order_type;
    private String invoice_date;
    private String currency_code;
    private String delivery_type;
    private double invoice_value;
    private String invoice_number;
    private int courier_partner;
    private String reference_number;
    private int height;
    private int length;
    private int breadth;
    
	/*
	 * public ShipmentDetails(List<Items> items, int weight, long order_id, int
	 * cod_value, String order_type, String invoice_date, String currency_code,
	 * String delivery_type, double invoice_value, String invoice_number, int
	 * courier_partner, String reference_number, int height, int length, int
	 * breadth) { super(); this.items = items; this.weight = weight; this.order_id =
	 * order_id; this.cod_value = cod_value; this.order_type = order_type;
	 * this.invoice_date = invoice_date; this.currency_code = currency_code;
	 * this.delivery_type = delivery_type; this.invoice_value = invoice_value;
	 * this.invoice_number = invoice_number; this.courier_partner = courier_partner;
	 * this.reference_number = reference_number; this.height = height; this.length =
	 * length; this.breadth = breadth; }
	 */
	public List<Items> getItems() {
		return items;
	}
	public void setItems(List<Items> items) {
		this.items = items;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public int getCod_value() {
		return cod_value;
	}
	public void setCod_value(int cod_value) {
		this.cod_value = cod_value;
	}
	public String getOrder_type() {
		return order_type;
	}
	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}
	public String getInvoice_date() {
		return invoice_date;
	}
	public void setInvoice_date(String invoice_date) {
		this.invoice_date = invoice_date;
	}
	public String getCurrency_code() {
		return currency_code;
	}
	public void setCurrency_code(String currency_code) {
		this.currency_code = currency_code;
	}
	public String getDelivery_type() {
		return delivery_type;
	}
	public void setDelivery_type(String delivery_type) {
		this.delivery_type = delivery_type;
	}
	public double getInvoice_value() {
		return invoice_value;
	}
	public void setInvoice_value(double invoice_value) {
		this.invoice_value = invoice_value;
	}
	public String getInvoice_number() {
		return invoice_number;
	}
	public void setInvoice_number(String invoice_number) {
		this.invoice_number = invoice_number;
	}
	public int getCourier_partner() {
		return courier_partner;
	}
	public void setCourier_partner(int courier_partner) {
		this.courier_partner = courier_partner;
	}
	public String getReference_number() {
		return reference_number;
	}
	public void setReference_number(String reference_number) {
		this.reference_number = reference_number;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}	
		
}
