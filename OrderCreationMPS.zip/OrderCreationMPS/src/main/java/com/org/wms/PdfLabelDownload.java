package com.org.wms;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.StringTokenizer;

import javax.print.DocPrintJob;

import java.io.File;
import java.io.FileInputStream;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.*;
import java.awt.print.PrinterJob;

public class PdfLabelDownload {
	
	private final static Logger LOGGER = Logger.getLogger(PdfLabelDownload.class.getName()); 
	
	public static void main(String[] args) {
		
		LOGGER.info("Started executing PdfLabelDownload - Main Method");
		if (args.length < 3) {
			System.out.println("Usage: PdfDownloading URL FilePath(/home/weblogic/) ");
		} else {
			DownloadPDFFromURL(args[0], args[1], args[2]);
		}
	}

	public static String DownloadPDFFromURL(String link, String filePath, String order_id) {
		String fileName = "";
		try {
			
			LOGGER.info("Started executing DownloadPDFFromURL - Label link -> "+ link +" for order Id "+ order_id);
			URL url = new URL(link);			
			StringTokenizer st = new StringTokenizer(url.getFile(), "/");
			while (st.hasMoreTokens()) {
				st.nextToken();
				if (st.countTokens() == 1) {
					fileName = st.nextToken();
				}
			}
			fileName = order_id +"_"+ fileName;
			
			InputStream in = url.openStream();
			FileOutputStream fos = new FileOutputStream(new File(filePath + fileName));
			int length = -1;
			byte[] buffer = new byte[50000];// buffer for portion of data from connection
			while ((length = in.read(buffer)) > -1) {
				fos.write(buffer, 0, length);
			}
			fos.close();
			in.close();
			LOGGER.info("End of DownloadPDFFromURL - Downloaded fileName -> "+ fileName);
		} catch (Exception e) {
			LOGGER.error("Error while Downloading label from the URL");
			e.printStackTrace();
		}
		
		return fileName;	
	}
	
	public static void PrintPDFFromURL(String printerName, String filePath, String fileName) {
		try {
			LOGGER.info("Started executing PrintPDFFromURL - Printer Name -> "+ printerName +" File Name -> "+ fileName);
			PDDocument doc = PDDocument.load(new FileInputStream(filePath+fileName));  //read pdf file.
			javax.print.PrintService[] service = PrinterJob.lookupPrintServices(); 
			DocPrintJob docPrintJob = null;

			int count = service.length;
			for (int i = 0; i < count; i++) {
			    if (service[i].getName().equalsIgnoreCase(printerName)) {
			        docPrintJob = service[i].createPrintJob();
			        i = count;
			    }
			}

			PrinterJob pjob = PrinterJob.getPrinterJob();
			pjob.setPrintService(docPrintJob.getPrintService());
			pjob.setJobName("job");
			doc.silentPrint(pjob);
			LOGGER.info("End of PrintPDFFromURL");
			
		} catch (Exception e) {
			LOGGER.error("Error while Printing label in the printer");
			e.printStackTrace();
		}

	}
}
