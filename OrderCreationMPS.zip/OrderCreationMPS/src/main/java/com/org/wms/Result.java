package com.org.wms;

public class Result {

	private String label;
	private String waybill;
	private String reference_number;
	private String security_key;
	private String sort_code;
	private String courier_name;
	private int courier_partner_id;
	private long tracking_id;
	private long order_id;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getWaybill() {
		return waybill;
	}
	public void setWaybill(String waybill) {
		this.waybill = waybill;
	}
	public String getReference_number() {
		return reference_number;
	}
	public void setReference_number(String reference_number) {
		this.reference_number = reference_number;
	}
	public String getSecurity_key() {
		return security_key;
	}
	public void setSecurity_key(String security_key) {
		this.security_key = security_key;
	}
	public String getSort_code() {
		return sort_code;
	}
	public void setSort_code(String sort_code) {
		this.sort_code = sort_code;
	}
	public String getCourier_name() {
		return courier_name;
	}
	public void setCourier_name(String courier_name) {
		this.courier_name = courier_name;
	}
	public int getCourier_partner_id() {
		return courier_partner_id;
	}
	public void setCourier_partner_id(int courier_partner_id) {
		this.courier_partner_id = courier_partner_id;
	}
	public long getTracking_id() {
		return tracking_id;
	}
	public void setTracking_id(long tracking_id) {
		this.tracking_id = tracking_id;
	}
	public long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}
	
}
