package com.org.wms;

public class BatchTrackingResult {
	
	private String waybill;
	private int courier_partner;
	private String created_at;
	private String updated_at;
	private int clickpost_status_code;
	private String timestamp;
	private String clickpost_status_description;
	private String reference_number;
	private String account_code;
	private String location;
	private String remark;
	private String status;
	private boolean customer_feedback_present;
	private String clickpost_city;
	
	public String getWaybill() {
		return waybill;
	}
	public void setWaybill(String waybill) {
		this.waybill = waybill;
	}
	public int getCourier_partner() {
		return courier_partner;
	}
	public void setCourier_partner(int courier_partner) {
		this.courier_partner = courier_partner;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public int getClickpost_status_code() {
		return clickpost_status_code;
	}
	public void setClickpost_status_code(int clickpost_status_code) {
		this.clickpost_status_code = clickpost_status_code;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getClickpost_status_description() {
		return clickpost_status_description;
	}
	public void setClickpost_status_description(String clickpost_status_description) {
		this.clickpost_status_description = clickpost_status_description;
	}
	public String getReference_number() {
		return reference_number;
	}
	public void setReference_number(String reference_number) {
		this.reference_number = reference_number;
	}
	public String getAccount_code() {
		return account_code;
	}
	public void setAccount_code(String account_code) {
		this.account_code = account_code;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean isCustomer_feedback_present() {
		return customer_feedback_present;
	}
	public void setCustomer_feedback_present(boolean customer_feedback_present) {
		this.customer_feedback_present = customer_feedback_present;
	}
	public String getClickpost_city() {
		return clickpost_city;
	}
	public void setClickpost_city(String clickpost_city) {
		this.clickpost_city = clickpost_city;
	}

}
