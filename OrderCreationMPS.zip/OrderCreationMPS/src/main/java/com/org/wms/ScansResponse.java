package com.org.wms;

public class ScansResponse {
	
	private String timestamp;
	private String location;
	private String remark;
	private String status;
	private int clickpost_status_code;
	private long checkpoint_id;
	private long tracking_id;
	private String created_at;
	private String clickpost_status_description;
	private int clickpost_status_bucket;
	private String clickpost_status_bucket_description;
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getClickpost_status_code() {
		return clickpost_status_code;
	}
	public void setClickpost_status_code(int clickpost_status_code) {
		this.clickpost_status_code = clickpost_status_code;
	}
	public long getCheckpoint_id() {
		return checkpoint_id;
	}
	public void setCheckpoint_id(long checkpoint_id) {
		this.checkpoint_id = checkpoint_id;
	}
	public long getTracking_id() {
		return tracking_id;
	}
	public void setTracking_id(long tracking_id) {
		this.tracking_id = tracking_id;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getClickpost_status_description() {
		return clickpost_status_description;
	}
	public void setClickpost_status_description(String clickpost_status_description) {
		this.clickpost_status_description = clickpost_status_description;
	}
	public int getClickpost_status_bucket() {
		return clickpost_status_bucket;
	}
	public void setClickpost_status_bucket(int clickpost_status_bucket) {
		this.clickpost_status_bucket = clickpost_status_bucket;
	}
	public String getClickpost_status_bucket_description() {
		return clickpost_status_bucket_description;
	}
	public void setClickpost_status_bucket_description(String clickpost_status_bucket_description) {
		this.clickpost_status_bucket_description = clickpost_status_bucket_description;
	}	
		
}	
