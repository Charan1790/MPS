package com.org.wms;

public class Additional {

	private String account_code;
	private boolean label;
	private String duty_fee_paid_by; 
	
	/*
	 * public Additional(String account_code, String order_id) { super();
	 * this.account_code = account_code; this.order_id = order_id; }
	 */
	
	public String getAccount_code() {
		return account_code;
	}
	public void setAccount_code(String account_code) {
		this.account_code = account_code;
	}
	public boolean isLabel() {
		return label;
	}
	public void setLabel(boolean label) {
		this.label = label;
	}
	public String getDuty_fee_paid_by() {
		return duty_fee_paid_by;
	}
	public void setDuty_fee_paid_by(String duty_fee_paid_by) {
		this.duty_fee_paid_by = duty_fee_paid_by;
	}
		
}
